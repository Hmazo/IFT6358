# IFT6358

Utilisation du serveur jekyll pour le blog :

# Execution et deploiement de la page :
Ouvrez une fenetre de commande dans le répertoire "blog". Executez la commande "bundle install" puis "bundle exec jekyll serve"
Cliquez sur le lien proposé, celà va oubrir un onglet directement sur le site

# Modifier un post :
Dans le répertoire _posts, il y a le milestone 1. Dans ce fichier.md, ajoutez votre texte au bon endroit.
Quelques instructions : 
- Pour un retour à la ligne, il faut faire **2** espaces en fin de ligne, puis Space.
- Les titres sont rangés par ordre décroissant de # : # Titre, ## Sous-titre, etc...
- Italique : *entre asterisques*, Gras : **entre deux asterisques**